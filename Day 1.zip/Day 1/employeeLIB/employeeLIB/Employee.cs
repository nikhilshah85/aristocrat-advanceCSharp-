﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace employeeLIB
{
    public class Employee
    {

        #region My Proprties
        public int empNo { get; set; }
        public string empName { get; set; }

        public string empDesignation { get; set; }
        public int empSalary { get; set; }
        #endregion

        #region My Methods
        public string GreetEmployee()
        {
            //write some greet message here
             return "Welcome";
        }

        public string EmployeeInfo(int p_empNo)
        {
            return "Hello From Method " +this.empNo + " Name : " + this.empName + " " + empDesignation; 
        }

        public int EmployeeBonus(int percentage)
        {
            return (this.empSalary * percentage) / 100;
        }
        #endregion




    }
}

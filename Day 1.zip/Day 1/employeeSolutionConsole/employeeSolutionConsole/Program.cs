﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using employeeLIB;
namespace employeeSolutionConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            //create a new object
            Employee empObj = new Employee()
            {
                empNo=105,
                empName="Neha",
                empDesignation="HR", 
                empSalary=90000
            };

          Console.WriteLine(empObj.EmployeeInfo(empObj.empNo));

            int bonusValue = empObj.EmployeeBonus(12);

            Console.WriteLine(bonusValue);
            
        }
    }
}

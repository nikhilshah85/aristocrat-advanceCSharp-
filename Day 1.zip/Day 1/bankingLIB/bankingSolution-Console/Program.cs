﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using bankingLIB;
namespace bankingSolution_Console
{
    class Program
    {
        
        static int secNo;
        static void Main(string[] args)
        {
            //Accounts acc = new Accounts();
            // Current cur = new Current(501, "Ruhi", 6000, 102);

            //Console.WriteLine(cur.accName);
            //Savings sav = new Savings(); //this means the account is created
            //PF pfObj = new PF();

            //Current acc = new Current();//a new child is born, by default he/she will inherit everything from parent
            //in the memoty, first accounts acc = new accounts() is created


            //Current acc = new Current(101, "Rohan", 6000, 102);
            //Savings sav = new Savings();

            //Console.WriteLine(sav.Add(20,50));

            //Console.WriteLine(sav.Add(1,2,5,6,7,8,9,4,32,345,345,456));
            // Console.WriteLine(sav.Add())


            //try
            //{
            //    Savings sav = new Savings();
            //    Current cur = new Current() { accBalance = 90000 };

            //    Console.WriteLine(cur.Widraw(95000));
            //}
            //catch (Exception es)
            //{
            //    Console.WriteLine(es.Message);
            //}
            //finally
            //{
            //    Console.WriteLine("Thank yu for banking");
            //}


            Savings sav1 = new Savings();
            Savings sav2 = new Savings();
            Savings sav3 = new Savings();
            Savings sav4 = new Savings();

            Current cur2 = new Current("Jay", 9000, 50);

            Console.WriteLine(sav1.accNo);
            Console.WriteLine(sav2.accNo);
            Console.WriteLine(sav3.accNo);
            Console.WriteLine(sav4.accNo);
            Console.WriteLine(cur2.accNo);

           // int firNo;

            //Program p = new Program();
            

          //  Console.WriteLine(secNo);

        }
    }
}

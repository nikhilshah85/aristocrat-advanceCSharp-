﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bankingLIB
{
    public class Current : Accounts
    {
        public bool isOdRequested { get; set; }
        public Current(string p_accName, double p_accBalance, int p_accBranch) : base( p_accName, p_accBalance, p_accBranch)
        {
            isOdRequested = false;
        }
        
        public override double Widraw(int p_amount)
        {
            if (p_amount > 75000)
            {
                throw new Exception(" Current account can widraw max 75000 in a single transaction");
            }
            return base.Widraw(p_amount);
        }
    }
}

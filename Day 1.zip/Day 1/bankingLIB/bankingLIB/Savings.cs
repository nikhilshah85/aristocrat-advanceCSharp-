﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bankingLIB
{
    public class Savings : Accounts
    {
        public int rateOfIntrest { get; set; }
        public Savings( string p_accName, double p_accBalance, int p_accBranch, int p_rateofIntrest) : base(p_accName, p_accBalance, p_accBranch)
        {
            this.rateOfIntrest = p_rateofIntrest;
        }

        public Savings(int p_accNo, string p_accName, double p_accBalance, int p_accBranch) : base(p_accName, p_accBalance, p_accBranch)
        { 
        }
        public Savings(): base("",5000,21)
        { }


        public int Add(int num1, int num2, params int[] morevalues)
        {

            int add = num1 + num2;
            int result = 0;
            for (int i = 0; i < morevalues.Length; i++)
            {
                result = result + morevalues[i];
            }
            return result + add;
        }

        public override double Widraw(int p_amount)
        {
            if (p_amount < 500 || p_amount > 25000)
            {
                
                throw new Exception("Widrawal has to be between 500 and 25K only");
            }
            return base.Widraw(p_amount);
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bankingLIB
{
    public abstract class Accounts
    {

        public int accNo { get; set; }

        public string accName { get; set; }

        public double accBalance { get; set; }
        public int accBranch { get; set; }

        static int v_autoNumber;

        public virtual double Widraw(int p_amount)
        {
            accBalance = accBalance - p_amount;
            return accBalance;
        }

        public double Deposit(int p_amount)
        {
            accBalance = accBalance + p_amount;
            return accBalance;
        }

        public Accounts() { }

        public Accounts( string p_accName, double p_accBalance, int p_accBranch)
        {
            
            this.accName = p_accName;
            this.accBalance = p_accBalance;
            this.accBranch = p_accBranch;
            //if everything is right

            v_autoNumber = v_autoNumber + 1;
            this.accNo = v_autoNumber;
        }
    }
}

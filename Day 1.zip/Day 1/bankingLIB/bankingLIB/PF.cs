﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bankingLIB
{
    public class PF : Accounts
    {
        public PF(string p_accName, double p_accBalance, int p_accBranch):base(p_accName,p_accBalance,p_accBranch)
        {

        }
     
    }
}

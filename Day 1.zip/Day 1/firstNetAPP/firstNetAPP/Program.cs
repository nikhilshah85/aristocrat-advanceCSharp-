﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace firstNetAPP
{
    class Program
    {
        static void Main(string[] args)
        {
            //entry point
            //Console.WriteLine("Hello ad Welcome to C#");

            //Console.WriteLine("Enter Your Name");
            //string userName = Console.ReadLine();
            //Console.WriteLine(" Welcome  " + userName);
            //Console.ReadLine();

            int age = 30;
            string name = "Nikhil";
            bool isPermenant = true;
            double height = 6.5;

            Console.WriteLine("Hello " + name);

            Console.ReadLine();

        }


    }
}




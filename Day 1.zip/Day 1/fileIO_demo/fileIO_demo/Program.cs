﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace fileIO_demo
{
    class Program
    {
        static void Main(string[] args)
        {

            #region Write to my File
            //FileStream myFile = new FileStream("myInfo.txt", FileMode.Create, FileAccess.Write);

            //StreamWriter pen = new StreamWriter(myFile);

            //pen.WriteLine("Hello Good evening");
            //pen.WriteLine("Hello Good evening 1");
            //pen.WriteLine("Hello Good evening 2");
            //pen.WriteLine("Hello Good evening 3");
            //pen.WriteLine("Hello Good evening 4");
            //pen.WriteLine("Hello Good evening 5");
            //pen.WriteLine("Nikhil");

            //pen.Close();
            //myFile.Close();

            #endregion

            #region Read from my file
            //FileStream myFile = new FileStream("myInfo.txt", FileMode.Open, FileAccess.Read);

            //StreamReader wr = new StreamReader(myFile);

            //Console.WriteLine(wr.ReadToEnd());
            #endregion

            //Savings Account =- SAV101 onwards, CUR501 onwards, PF2100 onwarwds
            //for (int i = 0; i < 10; i++)
            //{
                Accounts acc = new Accounts();  // I want to capture and store the objeect into some storage
            acc.accName = " Shalini";
            acc.accBranch = 101;
            acc.accBalance = 6000;
                Console.WriteLine("Account Created New Account is " + acc.accNo);
           // }
          
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace fileIO_demo
{
    class Accounts
    {
        public int accNo { get; set; }

        public string accName { get; set; }

        public double accBalance { get; set; }
        public int accBranch { get; set; }

        public Accounts()
        {
            int currentNo = 501;
            string filePath = "auto_accNo.txt";
            FileStream myFile = null;

            if (File.Exists(filePath))
            {
                myFile = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                StreamReader rd = new StreamReader(myFile);
                currentNo = Convert.ToInt32(rd.ReadLine());
                currentNo = currentNo + 1;
                this.accNo = currentNo;
                rd.Close();
                myFile.Close();

                myFile = new FileStream(filePath, FileMode.Create, FileAccess.Write);
                StreamWriter wr = new StreamWriter(myFile);
                wr.WriteLine(currentNo);
                wr.Close();
                myFile.Close();
            }
            else
            {
               myFile = new FileStream(filePath, FileMode.Create, FileAccess.Write);
                StreamWriter wr = new StreamWriter(myFile);
                wr.WriteLine(currentNo);
                wr.Close();
                myFile.Close();
                this.accNo = currentNo;
            }
        }
    }
}
